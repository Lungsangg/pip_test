from setuptools import setup

setup(name = 'calbmi_lungsang',
      version = '0.1',
      description = 'Calculate Body-Mass Indes',
      author = 'Lungsang',
      packages = ['calbmi_lungsang'],
      zip_safe = False)